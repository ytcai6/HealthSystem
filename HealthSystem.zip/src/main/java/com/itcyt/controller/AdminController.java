package com.itcyt.controller;

import com.itcyt.domain.Admin;
import com.itcyt.service.AdminService;
import org.apache.ibatis.jdbc.Null;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/{username}&{password}")
    public Result login(@PathVariable String username,@PathVariable String password) {
        Admin admin = adminService.login(username, password);
        return admin != null ? new Result(Code.LOGIN_REGISTER_OK, admin) : new Result(Code.LOGIN_REGISTER_ERR, null);
    }

    @PostMapping
    public Result register(@RequestBody Admin admin) {
        boolean isRegister = adminService.register(admin);
        return isRegister ? new Result(Code.LOGIN_REGISTER_OK, admin) : new Result(Code.LOGIN_REGISTER_ERR, null);
    }
}
