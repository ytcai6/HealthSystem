package com.itcyt.controller;

import com.itcyt.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class DocController {
    @Autowired
    PersonService personService;

    @PostMapping("/doc/{username}/{userPosition}/{health}")
    public ModelAndView test(@RequestParam(value = "file") MultipartFile file, @PathVariable String username, @PathVariable String userPosition, @PathVariable int health) {
        personService.uploadUpdate(file,health);
        ModelAndView mv = new ModelAndView();
        mv.addObject("admin", username);
        mv.addObject("position", userPosition);
        mv.setView(new RedirectView("http://localhost:8080/HealthSystem_war/pages/docResult.jsp"));
        return mv;
    }
}