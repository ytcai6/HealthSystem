package com.itcyt.controller;

import java.util.Base64.Encoder;
import org.apache.commons.codec.binary.Base64;
import com.itcyt.domain.PageBean;
import com.itcyt.domain.Person;
import com.itcyt.service.PersonService;
import com.mysql.jdbc.util.Base64Decoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/person")
public class PersonController {
    @Autowired
    PersonService personService;

    @GetMapping("/selectAll")
    public Result getAll() {
        List<Person> people = personService.selectAll();
        return people != null ? new Result(Code.GET_OK, people) : new Result(Code.GET_ERR, null, "数据获取失败");
    }

    @GetMapping("/selectAllByPage/{currentPage}/{pageSize}")
    public Result getAllByPage(@PathVariable int currentPage, @PathVariable int pageSize) {
        PageBean<Person> personPageBean = personService.selectByPage(currentPage, pageSize);
        return (personPageBean.getRows().size() > 0) && (personPageBean.getTotalCount() > 0) ?
                new Result(Code.GET_OK, personPageBean) : new Result(Code.GET_ERR, null, "数据获取失败");
    }

    @PostMapping("/selectByPageAndCondition/{currentPage}/{pageSize}")
    public Result selectByPageAndCondition(@PathVariable int currentPage, @PathVariable int pageSize, @RequestBody Person person) {
        PageBean<Person> personPageBean = personService.selectByPageAndCondition(currentPage, pageSize, person);
        return (personPageBean.getRows().size() > 0) && (personPageBean.getTotalCount() > 0) ?
                new Result(Code.GET_OK, personPageBean) : new Result(Code.GET_ERR, null, "数据获取失败");
    }


    @PostMapping("/selectByCondition")
    public Result selectByCondition(@RequestBody Person person) {
        System.out.println(person);
        List<Person> people = personService.selectByCondition(person);
        return people != null ? new Result(Code.GET_OK, people) : new Result(Code.GET_ERR, null, "数据获取失败");
    }

    @DeleteMapping("/{id}")
    public Result deleteById(@PathVariable("id") int id) {
        personService.deleteById(id);
        return new Result(Code.DELETE_OK, null);
    }

    @PostMapping("/deleteByIds")
    public Result deleteByIds(@RequestBody int[] ids) {
        personService.deleteByIds(ids);
        return new Result(Code.DELETE_OK, null);
    }

    @PostMapping("/add")
    public Result add(@RequestBody Person person) {
        personService.add(person);
        return new Result(Code.SAVE_OK, null);
    }

    @PostMapping("/editById")
    public Result editById(@RequestBody Person person) {
        personService.updateById(person);
        return new Result(Code.UPDATE_OK, null);
    }

    @PostMapping("/updateByPersonid")
    public Result updateByPersonid(@RequestBody Person person) {
        System.out.println(person);
        boolean updateByPersonid = personService.updateByPersonid(person.getPersonid(), person.getHealth());
        return updateByPersonid == true ? new Result(Code.UPDATE_OK, null) : new Result(Code.UPDATE_ERR, null);
    }

    @GetMapping("/getDateImage")
    public Result getDateImage() throws IOException {
        String result = personService.dataImage();
        return new Result(Code.GET_OK, result);
    }
}
