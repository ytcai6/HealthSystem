package com.itcyt.mapper;

import com.itcyt.domain.Admin;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface AdminMapper {
    @Select("select * from admin where username=#{username} and password=#{password}")
    Admin login(@Param("username") String username, @Param("password") String password);

    @Insert("insert into admin values (null,#{username},#{password},#{phoneNumber},#{userPosition})")
    boolean register(Admin admin);
}
