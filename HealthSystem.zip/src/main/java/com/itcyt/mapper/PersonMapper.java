package com.itcyt.mapper;

import com.itcyt.domain.Person;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface PersonMapper {

    @Select("select * from personinfo")
    List<Person> selectAll();

    @Select("select * from personinfo where personid = #{personid}")
    Person selectByPersonId(String personid);

    @Select("select * from personinfo where health = #{health} and personid = #{personid}")
    List<Person> selectByCondition(Person person);

    @Select("select * from personinfo limit #{begin},#{size}")
    List<Person> selectByPage(@Param("begin") int begin,@Param("size") int size);

    int selectTotalCountByCondition(Person person);

    List<Person> selectByPageAndCondition(@Param("begin")int begin, @Param("size")int size, @Param("person")Person person);

    /**
     * 数据库总人数
     * @return
     */
    @Select("select count(*) from personinfo")
    int selectTotalCount();

    /**
     * 红码人数
     * @return
     */
    @Select("select count(*) from personinfo where health = 2")
    int selectRedCount();

    /**
     * 绿码人数
     * @return
     */
    @Select("select count(*) from personinfo where health = 0")
    int selectGreenCount();

    /**
     * 黄码人数
     * @return
     */
    @Select("select count(*) from personinfo where health = 1")
    int selectYellowCount();


    @Insert("insert into personinfo values (null,#{personid}," +
            "#{name},#{phoneNumber},#{gender},#{health},#{address},#{travel});")
    void add(Person person);

    @Update("update personinfo set personid = #{personid},name = #{name}, phoneNumber=#{phoneNumber}," +
            "gender=#{gender},health=#{health},address=#{address},travel=#{travel} where id = #{id}")
    void updateById(Person person);

    @Update("update personinfo set health = #{health} where personid =#{personid}")
    void updateByPersonid(@Param("personid") String personind, @Param("health") int health);

    @Delete("delete from personinfo where id = #{id};")
    void deleteById(@Param("id")int id);

    void deleteByIds(@Param("ids")int[] ids);
}
