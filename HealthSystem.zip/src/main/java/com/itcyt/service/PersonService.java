package com.itcyt.service;

import com.itcyt.domain.PageBean;
import com.itcyt.domain.Person;
import org.springframework.web.multipart.MultipartFile;

import java.awt.image.BufferedImage;
import java.util.List;

public interface PersonService {
    List<Person> selectAll();

    Person selectByPersonid(String personid);

    List<Person> selectByCondition(Person person);

    int selectTotalCount();

    int selectRedCount();
    int selectGreenCount();
    int selectYellowCount();

    int selectTotalCountByCondition(Person person);

    PageBean<Person> selectByPage(int currentPage, int pageSize);

    PageBean<Person> selectByPageAndCondition(int currentPage, int pageSize, Person person);

    void add(Person person);

    void deleteById(int id);

    void deleteByIds(int[] ids);

    void updateById(Person person);

    boolean updateByPersonid(String personid, int health);

    void uploadUpdate(MultipartFile file,int health);

    String dataImage();
}
