package com.itcyt.service.impl;

import com.itcyt.mapper.AdminMapper;
import com.itcyt.domain.Admin;
import com.itcyt.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Admin login(String username, String password) {
        return adminMapper.login(username,password);
    }

    @Override
    public boolean register(Admin admin) {
        return adminMapper.register(admin);
    }
}
