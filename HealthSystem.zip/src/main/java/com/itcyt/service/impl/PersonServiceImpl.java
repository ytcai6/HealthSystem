package com.itcyt.service.impl;

import com.itcyt.domain.PageBean;
import com.itcyt.mapper.PersonMapper;
import com.itcyt.domain.Person;
import com.itcyt.service.PersonService;
import com.itcyt.util.ImageUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonMapper personMapper;

    @Override
    public List<Person> selectAll() {
        List<Person> personList = personMapper.selectAll();
        return personList;
    }

    @Override
    public Person selectByPersonid(String personid) {
        return personMapper.selectByPersonId(personid);
    }

    @Override
    public List<Person> selectByCondition(Person person) {
        List<Person> personList = personMapper.selectByCondition(person);
        return personList;
    }

    @Override
    public int selectTotalCount() {
        return personMapper.selectTotalCount();
    }

    @Override
    public int selectRedCount() {
        return personMapper.selectRedCount();
    }

    @Override
    public int selectGreenCount() {
        return personMapper.selectGreenCount();
    }

    @Override
    public int selectYellowCount() {
        return personMapper.selectYellowCount();
    }

    @Override
    public int selectTotalCountByCondition(Person person) {
        return personMapper.selectTotalCountByCondition(person);
    }

    @Override
    public PageBean<Person> selectByPage(int currentPage, int pageSize) {
        int begin = (currentPage - 1) * pageSize;
        int size = pageSize;
        List<Person> personList = personMapper.selectByPage(begin, size);
        int totalCount = personMapper.selectTotalCount();
        return new PageBean<>(totalCount,personList);
    }

    /**
     * 根据条件分页查询到
     * @param currentPage 当前查询的页码
     * @param pageSize 页面大小
     * @param person 包含限制条件
     * @return PageBean对象，包含总数目及数据列表对象
     */
    @Override
    public PageBean<Person> selectByPageAndCondition(int currentPage, int pageSize, Person person) {

        int begin = (currentPage - 1) * pageSize;
        int size = pageSize;

//        处理person条件，设置模糊表达式
        String personid = person.getPersonid();
        if (personid != null && personid.length() > 0) {
            person.setPersonid("%" + personid + "%");
        }
//     根据根据条件分页查询
        List<Person> rows = personMapper.selectByPageAndCondition(begin, size, person);
        int totalCount = personMapper.selectTotalCountByCondition(person);

        PageBean<Person> pageBean = new PageBean<>();
        pageBean.setRows(rows);
        pageBean.setTotalCount(totalCount);

        return pageBean;
    }

    @Override
    public void add(Person person) {
        personMapper.add(person);
    }

    @Override
    public void deleteById(int id) {
        personMapper.deleteById(id);
    }

    @Override
    public void deleteByIds(int[] ids) {
        personMapper.deleteByIds(ids);
    }

    public void updateById(Person person) {
        personMapper.updateById(person);
    }

    @Override
    public boolean updateByPersonid(String personid, int health) {
        Person person = personMapper.selectByPersonId(personid);
        if (person == null) {
            return false;
        } else {
            personMapper.updateByPersonid(personid,health);
            return true;
        }
    }

    @Override
    public void uploadUpdate(MultipartFile file, int health) {
        List<String> idList = new ArrayList<>();
        try {
            InputStream fileInputStream = file.getInputStream();
            Workbook workbook = new XSSFWorkbook(fileInputStream);
            //2:获取第一个工作表sheet
            Sheet sheet = workbook.getSheetAt(0);
            for (int runNum =0; runNum <=sheet.getLastRowNum();runNum++) {
                Row row = sheet.getRow(runNum);
                if (row != null) {
                    int minColIx = row.getFirstCellNum();
                    //遍历该行，获取每个cell元素
                    Cell cell = row.getCell(minColIx);
                    idList.add(cell.getStringCellValue());
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < idList.size(); i++) {
            updateByPersonid(idList.get(i), health);
        }
    }

    @Override
    public String dataImage() {
        ImageUtil imageUtil = new ImageUtil();
        int redCount = personMapper.selectRedCount();
        int yellowCount = personMapper.selectYellowCount();
        int greenCount = personMapper.selectGreenCount();
        int[] data = {redCount, yellowCount, greenCount};
        String[] column = {"红码", "黄码", "绿码"};
        Color[] colors = {Color.RED, Color.GRAY, Color.GREEN};
        BufferedImage bufferedImage = imageUtil.paintPlaneHistogram("疫情形势数据", data, column, colors);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();//io流
        try {
            ImageIO.write(bufferedImage, "png", baos);//写入流中
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] bytes = baos.toByteArray();//转换成字节
        String png_base64 = Base64.encodeBase64String(bytes);
        png_base64 = png_base64.replaceAll("\n", "").replaceAll("\r", "");//删除 \r\n
        String result = "data:image/jpg;base64," + png_base64;
        return result;
    }


}
